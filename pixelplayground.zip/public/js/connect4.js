var playerRood = "R";
var playerGeel = "G";
var currPlayer = playerRood;
var gameOver = false;
var bord;
var rows = 6;
var columns = 7;
var currColumns = [];
var gebruiker_id; // This will be set from the HTML

window.onload = function() {
    setGame();
    gebruiker_id = document.getElementById("gebruiker_id").value; // Set gebruiker_id from hidden input

    document.getElementById("save-highscore-btn").addEventListener("click", saveHighscore);
    document.getElementById("delete-highscore-btn").addEventListener("click", deleteHighscore);
}

function setGame() {
    bord = [];
    currColumns = Array(columns).fill(rows - 1);

    for (let r = 0; r < rows; r++) {
        let row = [];
        for (let c = 0; c < columns; c++) {
            row.push(' ');
            let tile = document.createElement("div");
            tile.id = `${r}-${c}`;
            tile.classList.add("game-tile");
            tile.addEventListener("click", setPiece);
            document.getElementById("game-bord").appendChild(tile);
        }
        bord.push(row);
    }
}

function setPiece() {
    if (gameOver) return;

    let [r, c] = this.id.split("-").map(Number);
    r = currColumns[c];

    if (r < 0) return;

    bord[r][c] = currPlayer;
    let tile = document.getElementById(`${r}-${c}`);
    tile.classList.add(currPlayer == playerRood ? "rood-stuk" : "geel-stuk");
    tile.style.animation = `drop ${r * 0.1 + 0.5}s ease-in`;

    currPlayer = currPlayer == playerRood ? playerGeel : playerRood;
    currColumns[c]--;

    checkWinnaar();
}

function checkWinnaar() {
    if (checkHorizontal() || checkVertical() || checkDiagonal() || checkAntiDiagonal()) {
        setWinnaar();
    }
}

function checkHorizontal() {
    for (let r = 0; r < rows; r++) {
        for (let c = 0; c < columns - 3; c++) {
            if (bord[r][c] != ' ' && bord[r][c] == bord[r][c+1] && bord[r][c+1] == bord[r][c+2] && bord[r][c+2] == bord[r][c+3]) {
                return true;
            }
        }
    }
    return false;
}

function checkVertical() {
    for (let c = 0; c < columns; c++) {
        for (let r = 0; r < rows - 3; r++) {
            if (bord[r][c] != ' ' && bord[r][c] == bord[r+1][c] && bord[r+1][c] == bord[r+2][c] && bord[r+2][c] == bord[r+3][c]) {
                return true;
            }
        }
    }
    return false;
}

function checkDiagonal() {
    for (let r = 0; r < rows - 3; r++) {
        for (let c = 0; c < columns - 3; c++) {
            if (bord[r][c] != ' ' && bord[r][c] == bord[r+1][c+1] && bord[r+1][c+1] == bord[r+2][c+2] && bord[r+2][c+2] == bord[r+3][c+3]) {
                return true;
            }
        }
    }
    return false;
}

function checkAntiDiagonal() {
    for (let r = 3; r < rows; r++) {
        for (let c = 0; c < columns - 3; c++) {
            if (bord[r][c] != ' ' && bord[r][c] == bord[r-1][c+1] && bord[r-1][c+1] == bord[r-2][c+2] && bord[r-2][c+2] == bord[r-3][c+3]) {
                return true;
            }
        }
    }
    return false;
}

function setWinnaar() {
    let winnaar = document.getElementById("game-winnaar");
    let winner = currPlayer == playerRood ? "Geel" : "Rood"; // The winner is the opponent of the current player
    winnaar.innerText = winner + " heeft gewonnen";
    gameOver = true;
}

function saveHighscore() {
    const game_id = 4;
    const highscore = 1; // Assuming 1 win per game

    fetch('save_highscore.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ gebruiker_id, game_id, highscore })
    })
    .then(response => response.json())
    .then(data => {
        console.log('Highscore saved:', data);
    })
    .catch(error => {
        console.error('Error saving highscore:', error);
    });
}

function deleteHighscore() {
    fetch('delete_highscore.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ gebruiker_id })
    })
    .then(response => response.json())
    .then(data => {
        console.log('Highscore deleted:', data);
    })
    .catch(error => {
        console.error('Error deleting highscore:', error);
    });
}