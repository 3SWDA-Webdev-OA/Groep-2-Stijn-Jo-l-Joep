let slideIndex = 0;
let slides = document.getElementsByClassName("slide");

function showSlides(n) {
    for (let i = 0; i < slides.length; i++) {
        slides[i].classList.remove("active");
    }
    slides[slideIndex].classList.add("active");
    slideIndex = (slideIndex + 1) % slides.length;
}

function plusSlides(n) {
    slideIndex = (slideIndex + n + slides.length) % slides.length;
    showSlides(slideIndex);
}

document.addEventListener("DOMContentLoaded", function() {
    showSlides(slideIndex);
    setInterval(() => {
        plusSlides(1);
    }, 3000); // Change image every 3 seconds
});
