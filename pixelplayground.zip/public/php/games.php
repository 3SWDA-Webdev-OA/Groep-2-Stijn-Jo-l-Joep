<?php
session_start();
$loggedIn = isset($_SESSION['username']);
?>

<?php include 'header.php'; ?>

<main class="home-container">
    <section class="introduction">
        <h2>Welcome to PixelPlayground Games</h2>
        <p>Discover a variety of games that you can play directly on our platform. Choose your favorite and start playing now!</p>
        <img src="../assets/images/introduction-image.png" alt="Introduction Image">
    </section>

    <section class="game-selection">
        <h2>All Games</h2>
        <div class="game-card">
            <h3>Connect 4</h3>
            <a href="connect4.php">Play Now</a>
        </div>
        <div class="game-card">
            <h3>Flappy Bird</h3>
            <a href="flappybird.php">Play Now</a>
        </div>
        <div class="game-card">
            <h3>Game 3</h3>
            <a href="game3.php">Play Now</a>
        </div>
        <!-- Add more games here -->
    </section>
</main>

<?php include 'footer.php'; ?>

<script src="../js/slideshow.js" defer></script>
