</main>
    <footer>
        <div class="footer-content">
            <div class="footer-section about">
                <h3>About PixelPlayground</h3>
                <p>PixelPlayground is a platform where you can enjoy a variety of games, compete in tournaments, and achieve badges.</p>
            </div>
            <div class="footer-section contact">
                <h3>Contact Us</h3>
                <p>Email: <a href="mailto:contact@pixelplayground.com">contact@pixelplayground.com</a></p>
                <div class="socials">
                    <a href="#"><img src="../assets/images/facebook-icon.png" alt="Facebook"></a>
                    <a href="#"><img src="../assets/images/x-icon.png" alt="X"></a>
                    <a href="#"><img src="../assets/images/instagram-icon.png" alt="Instagram"></a>
                    <a href="#"><img src="../assets/images/threads-icon.png" alt="Threads"></a>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2024 PixelPlayground. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
