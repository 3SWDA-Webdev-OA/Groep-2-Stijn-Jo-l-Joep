<?php
session_start();
?>

<?php include 'header.php'; ?>

<main>
    <div class="game-container">
        <h1>Connect 4</h1>
        <p>Welcome to Connect 4, <?php echo isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : "Guest"; ?>!</p>
        <h2 id="game-winnaar"></h2>
        <div id="game-bord"></div>
        <input type="hidden" id="gebruiker_id" value="<?php echo isset($_SESSION['gebruiker_id']) ? htmlspecialchars($_SESSION['gebruiker_id']) : ''; ?>">
        <button id="save-highscore-btn">Save Highscore</button>
        <button id="delete-highscore-btn">Delete Highscore</button>
    </div>
</main>

<?php include 'footer.php'; ?>

<script src="../js/connect4.js" defer></script>
