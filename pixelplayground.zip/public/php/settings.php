<?php
session_start();
include 'connection.php';

if (!isset($_SESSION['gebruiker_id'])) {
    header("Location: login.php");
    exit();
}

$gebruiker_id = $_SESSION['gebruiker_id'];
$error = '';
$success = '';

// Fetch user data
$stmt = $conn->prepare("SELECT * FROM gebruikers WHERE id = ?");
$stmt->bind_param("i", $gebruiker_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    echo "User not found.";
    exit();
}
$stmt->close();

// Set default values for profile picture and banner
$profile_picture = isset($user['profile_picture']) ? $user['profile_picture'] : 'images/default_profile_picture.png';
$banner = isset($user['banner']) ? $user['banner'] : 'images/default_banner.png';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $display_name = filter_input(INPUT_POST, 'display_name', FILTER_SANITIZE_STRING);
    $status = filter_input(INPUT_POST, 'status', FILTER_SANITIZE_STRING);
    $bio = filter_input(INPUT_POST, 'bio', FILTER_SANITIZE_STRING);
    $profile_picture_file = $_FILES['profile_picture'];
    $banner_file = $_FILES['banner'];

    // Handle profile picture upload
    if (isset($profile_picture_file) && $profile_picture_file['error'] == UPLOAD_ERR_OK) {
        $profile_picture_dir = 'images/profile_pictures/';
        if (!is_dir($profile_picture_dir)) {
            mkdir($profile_picture_dir, 0777, true);
        }
        $profile_picture = $profile_picture_dir . basename($profile_picture_file['name']);
        if (!move_uploaded_file($profile_picture_file['tmp_name'], $profile_picture)) {
            $error = "Failed to upload profile picture.";
        }
    }

    // Handle banner upload
    if (isset($banner_file) && $banner_file['error'] == UPLOAD_ERR_OK) {
        $banner_dir = 'images/banners/';
        if (!is_dir($banner_dir)) {
            mkdir($banner_dir, 0777, true);
        }
        $banner = $banner_dir . basename($banner_file['name']);
        if (!move_uploaded_file($banner_file['tmp_name'], $banner)) {
            $error = "Failed to upload banner.";
        }
    }

    if (empty($error)) {
        $stmt = $conn->prepare("UPDATE gebruikers SET display_name = ?, status = ?, bio = ?, profile_picture = ?, banner = ? WHERE id = ?");
        $stmt->bind_param("sssssi", $display_name, $status, $bio, $profile_picture, $banner, $gebruiker_id);

        if ($stmt->execute()) {
            $success = "Profile updated successfully.";
        } else {
            $error = "Profile update failed. Please try again.";
        }

        $stmt->close();
    }

    $conn->close();
}
?>

<?php include 'header.php'; ?>

<div class="container">
    <h2>Customise Profile</h2>
    <?php if (!empty($error)): ?>
        <div class="error-message"><?php echo $error; ?></div>
    <?php elseif (!empty($success)): ?>
        <div class="success-message"><?php echo $success; ?></div>
    <?php endif; ?>
    <form id="settings-form" method="post" enctype="multipart/form-data" action="settings.php">
        <label for="display_name">Display Name:</label>
        <input type="text" id="display_name" name="display_name" value="<?php echo htmlspecialchars($user['display_name']); ?>" required><br>
        <label for="status">Status:</label>
        <input type="text" id="status" name="status" value="<?php echo htmlspecialchars($user['status']); ?>" required><br>
        <label for="bio">Bio:</label>
        <textarea id="bio" name="bio" required><?php echo htmlspecialchars(isset($user['bio']) ? $user['bio'] : ''); ?></textarea><br>
        <label for="profile_picture">Profile Picture (512x512):</label>
        <input type="file" id="profile_picture" name="profile_picture" accept="image/*"><br>
        <label for="banner">Banner (468x60):</label>
        <input type="file" id="banner" name="banner" accept="image/*"><br>
        <input type="submit" value="Save Changes">
    </form>
</div>

<?php include 'footer.php'; ?>
