<?php
session_start();
$loggedIn = isset($_SESSION['username']);
?>

<?php include 'header.php'; ?>

<section class="information">
    <h2><b>Information</b></h2>
    <p>Welcome to PixelPlayground! Here you can find all the information about our platform and games.</p>
    <h2><b>Games Information</b></h2>
    <h3><b>Connect 4</b></h3>
 <P>  Connect 4 is a two-player connection game in which the players take turns dropping colored discs from the top into a seven-column, six-row vertically suspended grid. </p>
   <p> The objective of the game is to be the first to form a horizontal, vertical, or diagonal line of four of one's own discs.</p>

   <h3>Flappy bird</h3>

   <p>Flappy Bird is a mobile game developed by Vietnamese developer Dong Nguyen and released by his game development company, .Gears (dotGears), in May 2013.</P>
    <p> The game became a cultural phenomenon in early 2014 due to its addictive nature and high level of difficulty.</p>

<p>Gameplay:</p>

<b>Objective:</b> <p>The objective is to direct a flying bird, named "Faby," which moves continuously to the right, through sets of Mario-like pipes without hitting them.</p>
<b>Controls: </b> <p>The player controls the bird by tapping the screen to make it flap its wings, causing it to briefly ascend. If the screen is not tapped, the bird falls due to gravity.</p>
<b>Scoring:</b> <p>The player scores a point each time the bird successfully passes between a pair of pipes. The game ends when the bird collides with a pipe or the ground.</p>
    <!-- Add more informational content here -->
</section>

<?php include 'footer.php'; ?>
