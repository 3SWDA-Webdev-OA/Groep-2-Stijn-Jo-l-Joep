<?php
session_start();
$loggedIn = isset($_SESSION['username']);
?>

<?php include 'header.php'; ?>

<main class="home-container">
    <section class="introduction">
        <h2>Welcome to PixelPlayground</h2>
        <p>Discover a world of fun and excitement with PixelPlayground, your ultimate gaming hub. Whether you're a casual player or a competitive gamer, we have something for everyone. Dive into our selection of classic and modern games, challenge your friends, and climb the leaderboards!</p>

    </section>

    <section class="slideshow-container">
        <div class="slideshow">
            <div class="slide fade">
                <img src="../assets/images/pixelplaygroundlogo.jpg" alt="Connect 4">
                <div class="text"><a href="connect4.php" class="slide-button">Play Connect 4</a></div>
            </div>
            <div class="slide fade">
                <img src="../assets/images/pixelplaygroundlogo.jpg" alt="Game 2">
                <div class="text"><a href="flappybird.php" class="slide-button">Play flappy bird</a></div>
            </div>
            <div class="slide fade">
                <img src="../assets/images/pixelplaygroundlogo.jpg" alt="Game 3">
                <div class="text"><a href="tictacto.php" class="slide-button">Play Game 3</a></div>
            </div>
            <!-- Add more slides as needed -->
        </div>
    </section>

    <section class="features">
        <h2>Features</h2>
        <div class="feature-card">
            <h3>Competitive Tournaments</h3>
            <p>Join our weekly tournaments and compete with players from around the world. Show off your skills and win amazing prizes!</p>
        </div>
        <div class="feature-card">
            <h3>Achievements & Badges</h3>
            <p>Earn badges and achievements as you play and complete challenges. Collect them all and show them off on your profile!</p>
        </div>
        <div class="feature-card">
            <h3>Connect with Friends</h3>
            <p>Invite your friends, create teams, and play together. Stay connected and enjoy the gaming experience with your community.</p>
        </div>
        <div class="feature-card">
            <h3>Highscores & Leaderboards</h3>
            <p>Compete for the top spot on our leaderboards. Track your progress and see how you stack up against other players.</p>
        </div>
    </section>

    <section class="game-selection">
        <h2>Check out our games!</h2>
        <div class="game-card">
            <h3>Games page</h3>
            <a href="games.php">View games</a>
        </div>
        <!-- Add more games here -->
    </section>

    <section class="testimonials">
        <h2>What Our Players Say</h2>
        <div class="testimonial-card">
            <p>"PixelPlayground is the best place to unwind and enjoy some quality gaming time. The community is fantastic!"</p>
            <span>- Alex, Pro Gamer</span>
        </div>
        <div class="testimonial-card">
            <p>"I love the tournaments and the competitive spirit here. It's exciting to see my name on the leaderboards!"</p>
            <span>- Jamie, Competitive Player</span>
        </div>
    </section>

    <section class="call-to-action">
        <h2>Join the Fun Today!</h2>
        <p>Ready to start your gaming journey? Sign up now and become part of the PixelPlayground community.</p>
        <a href="register.php" class="cta-button">Register Now</a>
    </section>
</main>

<?php include 'footer.php'; ?>
<script src="../js/slideshow.js" defer></script>
