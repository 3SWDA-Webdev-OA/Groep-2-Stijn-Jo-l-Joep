<?php
session_start();
$loggedIn = isset($_SESSION['username']);
?>
<?php include 'header.php'; ?>
        <section class="contact">
            <h2>Contact Us</h2>
            <p>If you have any questions, feel free to reach out to us at <a href="mailto:contact@pixelplayground.com">contact@pixelplayground.com</a>.</p>
            <!-- Add more contact information here -->
        </section>
        <?php include 'footer.php'; ?>