<?php
// delete_highscore.php

session_start();
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['gebruiker_id'])) {
    $gebruiker_id = $data['gebruiker_id'];
    
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "pixelplayground";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die(json_encode(["status" => "error", "message" => $conn->connect_error]));
    }

    $stmt = $conn->prepare("DELETE FROM highscores WHERE gebruiker_id = ?");
    $stmt->bind_param("i", $gebruiker_id);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Highscore deleted"]);
    } else {
        echo json_encode(["status" => "error", "message" => $stmt->error]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["status" => "error", "message" => "Invalid data"]);
}
?>
