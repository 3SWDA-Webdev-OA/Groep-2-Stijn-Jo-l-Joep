<?php
session_start();
$loggedIn = isset($_SESSION['username']);

if (!$loggedIn) {
    header("Location: login.php");
    exit();
}
?>

<?php include 'header.php'; ?>

<main>
    <section class="dashboard">
        <h2>User Dashboard</h2>
        <div class="dashboard-cards">
            <div class="dashboard-card">
                <h3>Play a Game</h3>
                <a href="games.php">View Games</a>
            </div>
            <div class="dashboard-card">
                <h3>Check Badges/Achievements</h3>
                <a href="badges.php">View Badges</a>
            </div>
            <div class="dashboard-card">
                <h3>Check Tournaments</h3>
                <a href="toernooi.php">View Tournaments</a>
            </div>
            <div class="dashboard-card">
                <h3>Check Friends</h3>
                <a href="vrienden.php">View Friends</a>
            </div>
            <div class="dashboard-card">
                <h3>View Highscores</h3>
                <a href="highscore.php">View Highscores</a>
            </div>
            <div class="dashboard-card">
                <h3>Settings</h3>
                <a href="settings.php">Account Settings</a>
            </div>
        </div>
    </section>
</main>

<?php include 'footer.php'; ?>
