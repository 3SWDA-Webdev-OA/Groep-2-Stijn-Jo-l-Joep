<php

echo "echo does not require parentheses";

?>