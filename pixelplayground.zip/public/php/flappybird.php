<!DOCTYPE html>
<html>
<head>
    <title>Flappy Bird Game</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            height: 100vh;
            width: 100vw;
            background-image: url('../assets/images/jungle4.png');
            background-size: cover;
            overflow: hidden;
        }

        header {
            display: flex;
            justify-content: center;
            width: 100%;
            position: absolute;
            top: 20px;
        }

        .button-container {
            display: flex;
            gap: 10px;
        }

        button {
            padding: 10px 20px;
            font-size: 16px;
        }

        .bird {
            height: 80px;
            width: 100px;
            position: fixed;
            top: 40vh;
            left: 30vw;
            z-index: 100;
        }

        .pipe_sprite {
            position: fixed;
            top: 40vh;
            left: 100vw;
            height: 70vh;
            width: 6vw;
            background-image: url('../assets/images/stomp.png');
        }

        .message {
            position: fixed;
            z-index: 10;
            height: 10vh;
            font-size: 10vh;
            font-weight: 100;
            color: black;
            top: 12vh;
            left: 20vw;
            text-align: center;
        }

        .score {
            position: fixed;
            z-index: 10;
            height: 10vh;
            font-size: 10vh;
            font-weight: 100;
            color: goldenrod;
            top: 0;
            left: 0;
        }

        .score_val {
            color: gold;
        }
    </style>
</head>
<body>
<header>
    <div class="button-container">
        <button onclick="playSound()">Play Sound</button>
        <button onclick="pauseSound()">Pause Sound</button>
    </div>
</header>
<div class="background"></div>
<img class="bird" src="../assets/images/vogel.png" alt="bird-img">
<div class="message">Press Enter To Start Game</div>
<div class="score">
    <span class="score_title">Score: </span>
    <span class="score_val">0</span>
</div>

<script>
    var audio = new Audio('../assets/sounds/jungle.wav'); // Ensure the correct path to the audio file
    audio.loop = true; // Enable looping

    function playSound() {
        audio.play(); // Play the audio
    }

    function pauseSound() {
        audio.pause(); // Pause the audio
        audio.currentTime = 0; // Reset the audio to the beginning
    }
</script>
<script src="../js/flappybird.js" defer></script>
</body>
</html>