<?php
include 'connection.php';
session_start();
$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['register'])) {
        $username = filter_input(INPUT_POST, 'reg_username', FILTER_SANITIZE_STRING);
        $password = password_hash($_POST['reg_password'], PASSWORD_BCRYPT);
        $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
        $security_question = $_POST['security_question'];
        $security_answer = filter_input(INPUT_POST, 'security_answer', FILTER_SANITIZE_STRING);

        // Check if username already exists
        $stmt = $conn->prepare("SELECT * FROM gebruikers WHERE gebruikersnaam = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error = "Username already exists. Try a different one.";
        } else {
            // Insert new user
            $stmt = $conn->prepare("INSERT INTO gebruikers (gebruikersnaam, wachtwoord, email, security_question, security_answer) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $username, $password, $email, $security_question, $security_answer);

            if ($stmt->execute()) {
                $_SESSION['username'] = $username;
                $_SESSION['gebruiker_id'] = $stmt->insert_id; 
                header("Location: user_dashboard.php");
                exit();
            } else {
                $error = "Registration failed. Please try again.";
            }
        }
        $stmt->close();
    }
}
$conn->close();
?>

<?php include 'header.php'; ?>

<div class="container">
    <h2>Register</h2>
    <?php if (!empty($error)): ?>
        <div class="error-message"><?php echo $error; ?></div>
    <?php endif; ?>
    <form id="register-form" method="post" action="register.php">
        <label for="reg_username">Username:</label>
        <input type="text" id="reg_username" name="reg_username" required><br>
        <label for="reg_password">Password:</label>
        <input type="password" id="reg_password" name="reg_password" required><br>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br>
        <label for="security_question">Security Question:</label>
        <select id="security_question" name="security_question" required>
            <option value="pet">What is your pet's name?</option>
            <option value="mother">What is your mother's maiden name?</option>
            <option value="school">What is the name of your first school?</option>
        </select><br>
        <label for="security_answer">Security Answer:</label>
        <input type="text" id="security_answer" name="security_answer" required><br>
        <input type="submit" value="Register" name="register">
    </form>
</div>

<?php include 'footer.php'; ?>
