<?php
include 'connection.php';
session_start();

$error = '';

// If user is already logged in, redirect to user dashboard
if (isset($_SESSION['username']) && isset($_SESSION['gebruiker_id'])) {
    header("Location: friends.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Handle login
    if (isset($_POST['login'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];
        $stmt = $conn->prepare("SELECT * FROM gebruikers WHERE gebruikersnaam = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if (password_verify($password, $row['wachtwoord'])) {
                $_SESSION['username'] = $username;
                $_SESSION['gebruiker_id'] = $row['id'];
                header("Location: friends.php");
                exit();
            } else {
                $error = "Invalid password.";
            }
        } else {
            $error = "No user found with that username.";
        }
        $stmt->close();
    } 
    // Handle forgot username
    elseif (isset($_POST['forgot_username'])) {
        $security_question = $_POST['security_question'];
        $security_answer = $_POST['security_answer'];
        $stmt = $conn->prepare("SELECT gebruikersnaam FROM gebruikers WHERE security_question = ? AND security_answer = ?");
        $stmt->bind_param("ss", $security_question, $security_answer);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $success = "Your username is: " . htmlspecialchars($row['gebruikersnaam']);
        } else {
            $error = "No user found with that security question and answer.";
        }
        $stmt->close();
    }
}

$conn->close();
?>

<?php include 'header.php'; ?>

<div class="container">
    <h2>Login</h2>
    <?php if (!empty($error)): ?>
        <div class="error-message"><?php echo $error; ?></div>
    <?php elseif (!empty($success)): ?>
        <div class="success-message"><?php echo $success; ?></div>
    <?php endif; ?>

    <form id="login-form" method="post" action="login.php">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required><br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br>
        <input type="submit" value="Login" name="login">
        <p>Don't have an account? <a href="register.php">Register here</a></p>
        <p>Forgot your username? <a href="javascript:void(0);" onclick="toggleForgotUsername()">Click here</a></p>
    </form>

    <form id="forgot-username-form" method="post" action="login.php" style="display: none;">
        <label for="security_question">Security Question:</label>
        <select id="security_question" name="security_question" required>
            <option value="pet">What is your pet's name?</option>
            <option value="mother">What is your mother's maiden name?</option>
            <option value="school">What is the name of your first school?</option>
        </select><br>
        <label for="security_answer">Security Answer:</label>
        <input type="text" id="security_answer" name="security_answer" required><br>
        <input type="submit" value="Retrieve Username" name="forgot_username">
        <p>Remembered your username? <a href="javascript:void(0);" onclick="toggleForgotUsername()">Back to login</a></p>
    </form>
</div>

<?php include 'footer.php'; ?>

<script>
function toggleForgotUsername() {
    var loginForm = document.getElementById("login-form");
    var forgotUsernameForm = document.getElementById("forgot-username-form");
    if (loginForm.style.display === "none") {
        loginForm.style.display = "block";
        forgotUsernameForm.style.display = "none";
    } else {
        loginForm.style.display = "none";
        forgotUsernameForm.style.display = "block";
    }
}
</script>
