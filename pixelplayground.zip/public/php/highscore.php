<?php
session_start();
$loggedIn = isset($_SESSION['username']);

include 'connection.php'; 
?>

<?php include 'header.php'; ?>

<main class="score-container">
    <section class="introduction">
        <h2>Welcome to the most recent highscores!</h2>
        <p>Here you can see all past achieved highscores!</p>
    </section>
    <section class="highscores">
        <img src="../assets/images/high-scores.png" alt="highscore image">
    </section>

    <section class="highscore">
        <h3>High Scores</h3>
        <ul>
            <?php
            
            $query = "SELECT g.gebruikersnaam, h.highscore, h.timestamp 
                      FROM highscores h
                      JOIN gebruikers g ON h.gebruiker_id = g.id
                      ORDER BY h.highscore DESC LIMIT 1000";
            $result = $conn->query($query);

        
            if ($result === false) {
                echo "<li>Database query failed: " . $conn->error . "</li>";
            } else {
                if ($result->num_rows > 0) {
                   
                    while ($row = $result->fetch_assoc()) {
                        echo "<li>" . htmlspecialchars($row['gebruikersnaam']) . ": " . htmlspecialchars($row['highscore']) . " - " . htmlspecialchars($row['timestamp']) . "</li>";
                    }
                } else {
                    echo "<li>No high scores found.</li>";
                }
            }

            $conn->close();
            ?>
        </ul>
    </section>
</main>

<?php include 'footer.php'; ?>

<script src="../js/slideshow.js" defer></script>
