<?php
// save_highscore.php

session_start();
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['gebruiker_id'], $data['game_id'], $data['highscore'])) {
    $gebruiker_id = $data['gebruiker_id'];
    $game_id = $data['game_id'];
    $highscore = $data['highscore'];

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "pixelplayground";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die(json_encode(["status" => "error", "message" => $conn->connect_error]));
    }

    $stmt = $conn->prepare("INSERT INTO highscores (gebruiker_id, game_id, highscore) VALUES (?, ?, ?)");
    $stmt->bind_param("iii", $gebruiker_id, $game_id, $highscore);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Highscore saved"]);
    } else {
        echo json_encode(["status" => "error", "message" => $stmt->error]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["status" => "error", "message" => "Invalid data"]);
}
?>
