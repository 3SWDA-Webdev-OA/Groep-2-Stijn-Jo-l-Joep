<!DOCTYPE html>
<html>
<head>
    <title>PixelPlayground</title>
    <link rel="stylesheet" type="text/css" href="../css/styles.css">
    <script>
        function toggleMode() {
            var element = document.body;
            element.classList.toggle("dark-mode");
        }

        function toggleDropdown() {
            document.getElementById("dropdown-content").classList.toggle("show");
        }

        window.onclick = function(event) {
            if (!event.target.matches('.dropbtn')) {
                var dropdowns = document.getElementsByClassName("dropdown-content");
                for (var i = 0; i < dropdowns.length; i++) {
                    var openDropdown = dropdowns[i];
                    if (openDropdown.classList.contains('show')) {
                        openDropdown.classList.remove('show');
                    }
                }
            }
        }
    </script>
<link rel="apple-touch-icon" sizes="180x180" href="../assets/favicons/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="../assets/favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="../assets/favicons/favicon-16x16.png">
<link rel="manifest" href="../assets/favicons/site.webmanifest">
</head>
<body>
    <header>
        <div class="header-container">
            <div class="logo">
                <h1><a href="home.php">PixelPlayground</a></h1>
            </div>
            <nav>
                <div class="dropdown">
                    <button class="dropbtn" onclick="toggleDropdown()">Menu</button>
                    <div id="dropdown-content" class="dropdown-content">
                        <a href="home.php">Home</a>
                        <a href="games.php">Games</a>
                        <a href="information.php">Information</a>
                        <a href="contact.php">Contact</a>
                        <a href="highscore.php">latest highscore</a>
                        <a href="addfriends.php">Friends</a>
                        <?php if (isset($_SESSION['username'])): ?>
                            <a href="profile.php">Profile</a>
                            <a href="user_dashboard.php">Dashboard</a>
                        <?php else: ?>
                            <a href="login.php">Login</a>
                            <a href="register.php">Register</a>
                        <?php endif; ?>
                    </div>
                </div>
            </nav>
            <div class="user-info">
                <?php if (isset($_SESSION['username'])): ?>
                    <span>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                    <a href="profile.php" class="profile-link">Profile</a>
                    <a href="logout.php" class="logout-link">Logout</a>
                <?php else: ?>
                    <a href="login.php" class="login-link">Login</a>
                    <a href="register.php" class="register-link">Register</a>
                <?php endif; ?>
            </div>
            <button onclick="toggleMode()" class="mode-toggle-btn">Toggle `Dark/Light Mode`</button>
        </div>
    </header>
    <main>
