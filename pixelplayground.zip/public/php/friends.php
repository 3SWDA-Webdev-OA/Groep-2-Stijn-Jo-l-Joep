<?php
session_start();
include 'connection.php';

if (!isset($_SESSION['username']) || !isset($_SESSION['gebruiker_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['gebruiker_id'];

// Handle friend request
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['friend_username'])) {
    $friend_username = $_POST['friend_username'];
    $stmt = $conn->prepare("SELECT id FROM gebruikers WHERE gebruikersnaam = ?");
    $stmt->bind_param("s", $friend_username);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result && $result->num_rows > 0) {
        $friend = $result->fetch_assoc();
        $friend_id = $friend['id'];
        $stmt = $conn->prepare("INSERT INTO vrienden (gebruiker_id, vriend_id) VALUES (?, ?)");
        $stmt->bind_param("ii", $user_id, $friend_id);
        if ($stmt->execute()) {
            echo "Friend request sent to $friend_username";
        } else {
            echo "Error: " . $stmt->error;
        }
    } else {
        echo "User not found";
    }
    $stmt->close();
}

// Fetch friend requests
$stmt = $conn->prepare("SELECT gebruikers.gebruikersnaam FROM vrienden JOIN gebruikers ON vrienden.gebruiker_id = gebruikers.id WHERE vrienden.vriend_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Friends</title>
</head>
<body>
    <h2>Welcome, <?php echo $_SESSION['username']; ?></h2>
    <form method="post" action="">
        <label for="friend_username">Add Friend by Username:</label>
        <input type="text" id="friend_username" name="friend_username" required>
        <button type="submit">Add Friend</button>
    </form>

    <h3>Friend Requests:</h3>
    <ul>
        <?php
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<li>" . $row['gebruikersnaam'] . "</li>";
            }
        } else {
            echo "<li>No friend requests</li>";
        }
        ?>
    </ul>
</body>
</html>
