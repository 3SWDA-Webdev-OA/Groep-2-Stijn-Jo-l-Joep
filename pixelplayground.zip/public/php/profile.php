<?php
session_start();
include 'connection.php';

if (!isset($_SESSION['gebruiker_id'])) {
    header("Location: login.php");
    exit();
}

$gebruiker_id = $_SESSION['gebruiker_id'];
$stmt = $conn->prepare("SELECT * FROM gebruikers WHERE id = ?");
$stmt->bind_param("i", $gebruiker_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    echo "User not found.";
    exit();
}

$display_name = isset($user['display_name']) ? $user['display_name'] : 'Default Display Name';
$profile_picture = isset($user['profile_picture']) ? $user['profile_picture'] : 'images/default_profile_picture.png';
$banner = isset($user['banner']) ? $user['banner'] : 'images/default_banner.png';
$status = isset($user['status']) ? $user['status'] : 'No status available';
$bio = isset($user['bio']) ? $user['bio'] : 'No bio available';

$stmt->close();
$conn->close();
?>

<?php include 'header.php'; ?>

<div class="profile-container">
    <div class="profile-banner" style="background-image: url('<?php echo htmlspecialchars($banner); ?>');">
        <h1>PixelPlayground</h1>
    </div>
    <div class="profile-header">
        <img src="<?php echo htmlspecialchars($profile_picture); ?>" alt="Profile Picture" class="profile-picture">
        <div class="profile-info">
            <h2><?php echo htmlspecialchars($display_name); ?></h2>
            <p><?php echo htmlspecialchars($status); ?></p>
            <p><?php echo htmlspecialchars($bio); ?></p>
        </div>
        <a href="settings.php" class="customise-profile-btn">Customise Profile</a>
    </div>
    <!-- Display badges and highscores here -->
</div>

<?php include 'footer.php'; ?>
