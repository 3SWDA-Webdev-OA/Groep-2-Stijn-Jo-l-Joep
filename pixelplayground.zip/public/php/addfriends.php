<?php
session_start();
$loggedIn = isset($_SESSION['username']);
?>

<?php include 'header.php'; ?>

<main>
    <section class="game-selection">
        <h2>Add your favorite people here to play some fun games with!</h2>
        <div class="addfriends">
            <p>Add your friends</p>
            <?php if ($loggedIn): ?>
                <button onclick="window.location.href='friends.php'">Click here!</button>
            <?php else: ?>
                <span>Please log in to add friends.</span>
            <?php endif; ?>
        </div>
    </section>
</main>

<?php include 'footer.php'; ?>

<script src="../js/slideshow.js" defer></script>
